import com.google.gson.JsonObject;

import java.util.LinkedList;

/**
 * Implementa una estación de bicing
 */
public class EstacionBicing extends Ubicacion {
    /**
     * Id de la estación de bicing
     */
    private int id;
    /**
     * Tipo de estación
     */
    private String tipo;
    /**
     * Numero de slots de la estacion
     */
    private int slots;
    /**
     * Numero de bicis en la estacion
     */
    private int bikes;
    /**
     * Ids de las estaciones más cercanas
     */
    private int[] id_estaciones;
    /**
     * Estaciones más cercanas
     */
    private LinkedList<EstacionBicing> estaciones;
    /**
     * Id de la estación más lejana
     */
    private int legana;

    /**
     * Crea una nueva estación de bicing con los valores por defecto
     */
    public EstacionBicing () {}

    /**
     * Crea una nueva estación de bicing con los valores del JsonObject
     * @param estacion JsonObject con el que se inicializa la estación
     */
    public EstacionBicing (JsonObject estacion){

        super(estacion.get("latitude").getAsFloat(), estacion.get("longitude").getAsFloat(), estacion.get("altitude").getAsFloat(), estacion.get("streetName").getAsString(), estacion.get("streetNumber").getAsString());
        String sestaciones= estacion.get("nearbyStations").getAsString();
        id = estacion.get("id").getAsInt();
        tipo = estacion.get("type").getAsString();
        slots = estacion.get("slots").getAsInt();
        bikes = estacion.get("bikes").getAsInt();
        id_estaciones = new int[sestaciones.length()];
        String aux[];
        aux = sestaciones.split(", ");
        for (int i = 0; i < aux.length ; i++) {
            id_estaciones[i] = Integer.parseInt(aux[i]);
        }
    }

    /**
     *Añade a la lista enlazada de estaciones más cercanas según el identificador de las estaciones más cercanas
     * @param bicing lista enlazada que contiene todas las estaciones de bicing
     */
    public void assignaestacio (LinkedList<EstacionBicing> bicing){
        estaciones = new LinkedList<>();
        for (int i = 0; i < id_estaciones.length; i++){
            for (int j = 0; j < bicing.size(); j++){
                if (id_estaciones[i] == bicing.get(j).getId()){
                    EstacionBicing eb = bicing.get(j);
                    estaciones.add(eb);
                }
            }
        }
    }

    /**
     * Devuelve la distancia de la estación más lejana a esta
     * @param llbicing lista enlazada que contiene todas las estaciones de bicing
     * @return float distancia a la estación más lejana
     */
    public float masLegana (LinkedList<EstacionBicing> llbicing){
        int tam = llbicing.size();
        EstacionBicing aux = llbicing.get(0);

        float mayordistancia = 0;
        legana = 0;

        for (int i = 0; i < tam; i++) {
            aux = llbicing.get(i);
            float distancia = (float) Math.sqrt((Math.pow(this.getLatitud() - aux.getLatitud(), 2.0) + Math.pow (this.getLongitud() - aux.getLongitud(), 2.0)));
            if (distancia > mayordistancia) {
                mayordistancia = distancia;
                legana = i;
            }
        }
        return mayordistancia;
    }

    /**
     * Devuelve las estaciones más cercanas a ésta en una lista enlazada
     * @return LinkedList<EstacionBicing> las estaciones más cercanas a ésta
     */
    public LinkedList<EstacionBicing> getEstaciones() {
        return estaciones;
    }

    /**
     * Devuelve el numero de slots de la estacion
     * @return int el numero de slots de la estacion
     */
    public int getSlots() {
        return slots;
    }

    /**
     * Devuelve el numero de bicis de la estacion
     * @return int el numero de bicis de la estacion
     */
    public int getBikes() {
        return bikes;
    }

    /**
     * Devuelve el id de la estacion
     * @return int el id de la estacion
     */
    public int getId (){
        return id;
    }

    /**
     * Devuelve el id de la estación más lejana
     * @return int el id de la estacion más lejana
     */
    public int getLegana () {return legana;}
}