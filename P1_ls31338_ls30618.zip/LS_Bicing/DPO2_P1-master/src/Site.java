import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Implementa un sitio, que suele ser una ubicación comercial
 */
public class Site extends Ubicacion {
    /**
     * Nombre del sitio
     */
    private String name;
    /**
     * Estado de disponibilidad al público
     */
    private String open;
    /**
     * Valoración de los usuarios
     */
    private String rating;

    /**
     * Crea un nuevo sitio con los valores por defecto
     */
    public Site (){};

    /**
     * Crea un nuevo sitio a partir de un JsonObject
     * @param jo JsonObject que da información sobre como debe ser el sitio
     */
    public Site (JsonObject jo){
        super(jo);
        name = jo.get("name").getAsString();
        try {
            rating = jo.get("rating").getAsString();
        } catch (NullPointerException e){
            rating = "No Valorado";
        }

        try {
            JsonObject aux = jo.get("opening_hours").getAsJsonObject();
            open = Boolean.toString(aux.get("open_now").getAsBoolean());
        } catch (NullPointerException npe){
            open = "Informació no donada.";
        }

    }

    /**
     * Crea un nuevo sitio a partir de un nombre i una dirección
     * @param nombre nombre del sitio
     * @param calle dirección del sitio
     */
    public Site (String nombre, String calle){
        name = nombre;
        super.setCalle(calle);
    }

    /**
     * Devuelve el nombre del sitio
     * @return String el nombre del sitio
     */
    public String getName() {
        return name;
    }

    /**
     * Devuelve el estado del sitio
     * @return boolean si està abierto o no
     */
    public boolean isOpen() {
        return open.equals("true");
    }

    /**
     * Devuelve el negado del estado del sitio
     * @return boolean si està cerrado o no
     */
    public boolean isNotOpen(){
        return open.equals("false");
    }

    /**
     * Devuelve el estado del sitio
     * @return boolean si està abierto o no
     */
    public String getOpen(){
        return open;
    }

    /**
     * Devuelve el rating del sitio
     * @return String la valoración del sitio
     */
    public String getRating() {
        return rating;
    }

}
