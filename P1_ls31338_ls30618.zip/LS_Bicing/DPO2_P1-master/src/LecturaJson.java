import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Implementa un lector de fichero json
 */
public class LecturaJson {
    /**
     * Booleano que indica si la respuesta del servidor al enviar una consulta es correcta
     */
    private boolean existeubicacion;

    /**
     * Crea un nuevo LecturaJson en el que existe la ubicacion
     */
    public LecturaJson (){
        existeubicacion = true;
    }

    /**
     * Convierte un string json a JsonArray
     * @param info string json
     * @return JsonArray de estaciones de bicing información estructurada en JsonArray
     */
    public JsonArray stringToBicing(String info){

        JsonParser parser = new JsonParser();
        JsonObject obj = (JsonObject) parser.parse(info);
        JsonArray jarray = (JsonArray) obj.get("stations");

        return jarray;
    }

    /**
     * Convierte un string json a JsonObject
     * @param info string json
     * @return JsonObject información estructurada en JsonObject
     */
    public JsonObject stringToUbicacion (String info){
        existeubicacion = true;

        JsonParser parser = new JsonParser();
        JsonObject obj = (JsonObject) parser.parse(info);
        JsonArray jarray = (JsonArray) obj.get("results");
        JsonObject joubi = new JsonObject();
        if (!("OK".equals(obj.get("status").getAsString()))){
            existeubicacion = false;
        } else {
            joubi = (JsonObject) jarray.get(0);
        }
        return joubi;

    }

    /**
     * Convierte un string json a JsonArray
     * @param info string json
     * @return JsonArray de sitios información estructurada en JsonArray
     */
    public JsonArray stringToSites (String info){
        existeubicacion = true;

        JsonParser parser = new JsonParser();
        JsonObject obj = (JsonObject) parser.parse(info);
        JsonArray jarray = (JsonArray) obj.get("results");
        JsonArray joubi = new JsonArray();
        if (!("OK".equals(obj.get("status").getAsString()))){
            existeubicacion = false;
        } else {
            joubi = jarray;
        }
        return joubi;

    }

    /**
     * Devuelve una ruta a partir de un string json
     * @param info el String json
     * @return Ruta la ruta resultante
     */
    public Ruta infoToRuta (String info, Ruta ruta){
        int tiempo = 0;
        int distancia = 0;
        JsonParser parser = new JsonParser();
        JsonObject obj = (JsonObject) parser.parse(info);
        JsonArray inici = obj.get("origin_addresses").getAsJsonArray();
        ruta.setSsalida(inici.get(0).getAsString());
        JsonArray llegada = obj.get("destination_addresses").getAsJsonArray();
        ruta.setSllegada(llegada.get(llegada.size()-1).getAsString());

        JsonArray casillas = (JsonArray) obj.get("rows");

        for (int i = 0; i < casillas.size(); i++){
            JsonObject elements = casillas.get(i).getAsJsonObject();
            JsonArray asdf = elements.get("elements").getAsJsonArray();
            JsonObject joinfo = asdf.get(i).getAsJsonObject();

            JsonObject distance = joinfo.get("distance").getAsJsonObject();
            distancia = distancia + distance.get("value").getAsInt();

            JsonObject duration = joinfo.get("duration").getAsJsonObject();
            tiempo = tiempo + duration.get("value").getAsInt();
        }

        ruta.setDistacia(distancia);
        ruta.setTiempo(tiempo);

        return ruta;
    }

    /**
     * Comprueva que exista la ubicacion
     * @return boolean si exxiste la ubicacion o no
     */
    public boolean existeubicacion (){
        return existeubicacion;
    }
}
