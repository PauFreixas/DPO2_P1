import com.google.gson.JsonObject;

import java.util.LinkedList;

/**
 * Impementa una ubicación
 */
public class Ubicacion {
    /**
     * Id de la ubicación
     */
    private String id;
    /**
     * Coordenada de latitud
     */
    private float latitud;
    /**
     * Coordenada de longitud
     */
    private float longitud;
    /**
     * Altura de la ubicación
     */
    private float altitud;
    /**
     * Direccion de la ubicacion
     */
    private String calle;

    /**
     * Contador de las veces que la ubicación ha aparecido en el programa
     */
    private int cont;

    /**
     * Crea una nueva ubicación con los valores por defecto
     */
    public Ubicacion (){}

    /**
     * Crea una nueva ubicación con los parámetros especificados
     * @param latitud latitud de la ubicación
     * @param longitud longitud de la ubicación
     * @param altitud altitud de la ubicación
     * @param calle dirección de la ubicación
     * @param num numero de la ubicación
     */
    public Ubicacion (float latitud, float longitud, float altitud, String calle, String num){
        this.latitud = latitud;
        this.longitud = longitud;
        this.altitud = altitud;
        this.calle = calle + ", " + num;
        this.cont = 0;
    }

    /**
     * Crea una ubicación a partir de un JsonObject
     * @param ubicacion JsonObject que aporta información sobre la ubicación
     */
    public Ubicacion (JsonObject ubicacion) {
        this.id = ubicacion.get("id").getAsString();
        this.calle = ubicacion.get("formatted_address").getAsString();
        JsonObject aux = ubicacion.get("geometry").getAsJsonObject();
        JsonObject location = aux.get("location").getAsJsonObject();
        this.latitud = location.get("lat").getAsFloat();
        this.longitud = location.get("lng").getAsFloat();
        this.cont = 0;
    }

    /**
     * Calcula la estación de bicing más cercana
     * @param llbicing lista enlazada de estaciones de bicing
     * @return EstacionBicing la estacion más cercana
     */
    public EstacionBicing calcularEstacionMasCercana (LinkedList<EstacionBicing> llbicing) {
        int tam = llbicing.size();
        Ubicacion aux = llbicing.get(0);

        float distancia = (float) Math.sqrt((Math.pow(this.getLatitud() - aux.getLatitud(), 2.0) + Math.pow (this.getLongitud() - aux.getLongitud(), 2.0)));

        float menordistancia = distancia;
        int posicionmenordist = 0;

        for (int i = 0; i < tam; i++) {
            aux = llbicing.get(i);
            distancia = (float) Math.sqrt((Math.pow(this.getLatitud() - aux.getLatitud(), 2.0) + Math.pow (this.getLongitud() - aux.getLongitud(), 2.0)));
            if (distancia < menordistancia) {
                menordistancia = distancia;
                posicionmenordist = i;
            }
        }

        return llbicing.get(posicionmenordist);
    }

    /**
     * Incrementa en 1 el contador
     */
    public void sumCont (){
        cont = cont + 1;
    }

    /**
     * Devuelve la calle de la ubicación
     * @return String la calle de la ubicación
     */
    public String getCalle() {
        return calle;
    }

    /**
     * Fija la calle de la ubicación
     * @param calle dirección de la ubicación
     */
    public void setCalle(String calle) {
        this.calle = calle;
    }

    /**
     * Devuelve la latitud
     * @return float la latitud
     */
    public float getLatitud() {
        return latitud;
    }

    /**
     * Devuelve la longitud
     * @return float la longitud
     */
    public float getLongitud() {
        return longitud;
    }

    /**
     * Devuelve el contador
     * @return int el contador
     */
    public int getCont() {
        return cont;
    }


}
