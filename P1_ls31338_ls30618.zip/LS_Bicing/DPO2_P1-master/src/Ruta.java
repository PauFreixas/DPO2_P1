import com.google.gson.JsonObject;

import java.util.LinkedList;

/**
 * Implementa una ruta de una ubicación de salida a una ubicación de llegada pasando por las dos estaciones de bicing más cercanas a la salida y llegada
 */
public class Ruta {
    /**
     * Nombre de la ubicación de salida
     */
    private String ssalida;
    /**
     * Nombre de la ubicación de llegada
     */
    private String sllegada;
    /**
     * Ubicación de salida
     */
    private Ubicacion usalida;
    /**
     * Ubicación de llegada
     */
    private Ubicacion ullegada;
    /**
     * Estación de bicing más cercana a la ubicación de salida
     */
    private EstacionBicing ebsalida;
    /**
     * Estación de bicing más cercana a la ubicación de llegada
     */
    private EstacionBicing ebllegada;
    /**
     * Tiempo total del recorrido
     */
    private int tiempo;
    /**
     * Distancia total del recorrido
     */
    private int distacia;

    /**
     * Crea una nueva ruta con sus valores por defecto nulos
     */
    public Ruta (){}

    /**
     * Crea una nueva ruta con distancia i
     * @param i distancia que debe tener la ruta
     */
    public Ruta (int i){
        distacia = i;
    }

    /**
     * Comprueva que existan ubicaciones associadas a los nombres que recibe, de ser así inicializa la estacion de
     * salida y la de llegada para que sean las más cercanas al orígen y al destino
     * @param ssalida nombre de la estacion de salida
     * @param sllegada nombre de la estacion de llegada
     * @param llestacion lista enlazada de Estaciones de bicing
     * @return boolean si las ubicaciones que referencian ssalida y ssllegada existen o no
     */
    public boolean iniciarRuta (String ssalida, String sllegada, LinkedList<EstacionBicing> llestacion){
        LecturaJson lj = new LecturaJson();
        WebService ws = new WebService();

        JsonObject aux = lj.stringToUbicacion(ws.getSiteUrl(ssalida));

        if (!lj.existeubicacion()){
            return false;
        }

        usalida = new Ubicacion(aux);

        aux = lj.stringToUbicacion(ws.getSiteUrl(sllegada));

        if (!lj.existeubicacion()){
            return false;
        }
        ullegada = new Ubicacion(aux);

        ebsalida = usalida.calcularEstacionMasCercana(llestacion);
        ebllegada = ullegada.calcularEstacionMasCercana(llestacion);

        return true;
    }

    /**
     * Asigna a la estación de salida la estación más cercana que tenga bicis
     */
    public void comprobarEBSalida (){
        while (ebsalida.getBikes() < 1){
            ebsalida = ebsalida.getEstaciones().get(0);
        }
    }

    /**
     * Devuelve la ubicacion de salida
     * @return Ubicacion de salida
     */
    public Ubicacion getUsalida() {
        return usalida;
    }

    /**
     * Devuelve la ubicacion de llegada
     * @return Ubicacion de llegada
     */
    public Ubicacion getUllegada() {
        return ullegada;
    }

    /**
     * Devuelve la estacion de bicing de salida
     * @return EstacionBicing de salida
     */
    public EstacionBicing getEbsalida() {
        return ebsalida;
    }

    /**
     * Devuelve la estacion de bicing de llegada
     * @return EstacionBicing de llegada
     */
    public EstacionBicing getEbllegada() {
        return ebllegada;
    }

    /**
     * Devuelve el tiempo de la ruta
     * @return int tiempo de la ruta
     */
    public int getTiempo() {
        return tiempo;
    }

    /**
     * Fija el tiempo de la ruta
     * @param tiempo la duración de la ruta
     */
    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }

    /**
     * Devuelve la distancia de la ruta
     * @return int distancia de la ruta
     */
    public int getDistacia() {
        return distacia;
    }

    /**
     * Fija la distancia de la ruta
     * @param distacia la distancia total de la ruta
     */
    public void setDistacia(int distacia) {
        this.distacia = distacia;
    }

    /**
     * Devuelve el nombre de la ubicación de salida
     * @return String ssalida la dirección de la ubicación de salida
     */
    public String getSsalida() {
        return ssalida;
    }

    /**
     * Fija el nombre de la ubicación de salida
     * @param ssalida la dirección de la ubicación de salida
     */
    public void setSsalida(String ssalida) {
        this.ssalida = ssalida;
    }

    /**
     * Devuelve el nombre de la ubicación de llegada
     * @return String ssalida la dirección de la ubicación de llegada
     */
    public String getSllegada() {
        return sllegada;
    }


    /**
     * Fija el nombre de la ubicación de llegada
     * @param sllegada la dirección de la ubicación de llegada
     */
    public void setSllegada(String sllegada) {
        this.sllegada = sllegada;
    }
}
