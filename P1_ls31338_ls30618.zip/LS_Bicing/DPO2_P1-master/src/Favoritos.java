import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.*;
import java.util.LinkedList;

/**
 * Gestiona la introducción y el guardado de los datos en un archivo de sitios favoritos en formato .json
 */
public class Favoritos {
    /**
     * Lista enlazada de favoritos que se carga a partir de un fichero .json
     */
    LinkedList<Site> favoritos;
    /**
     * Interfície de linea de comandos
     */
    MostrarPantalla mp;

    /**
     * Constructor per defecto que carga la información del fitxer .json en una lista enlazada
     * @param archivo el nombre del archivo .json
     */
    public Favoritos (String archivo){
        favoritos = new LinkedList<Site>();
        String info;
        try {
            FileReader fr = new FileReader(archivo);
            BufferedReader br = new BufferedReader(fr);
            info = br.readLine();

            JsonParser parser = new JsonParser();
            JsonObject jofavoritos = (JsonObject) parser.parse(info);
            JsonArray jafavoritos = jofavoritos.get("favorites").getAsJsonArray();
            for (int i = 0; i < jafavoritos.size(); i++){
                JsonObject aux = jafavoritos.get(i).getAsJsonObject();
                favoritos.add(new Site(aux.get("name").getAsString(), aux.get("street").getAsString()));
            }
        } catch (FileNotFoundException file){
            mp.error("El archivo favorites_places.json no existe."+
                    "\nEl programa creará uno automáticamente.");
            try {
                FileWriter fw = new FileWriter(archivo);
                fw.close();
            } catch (IOException e){
                e.printStackTrace();
            }
        } catch (IOException io){
            mp.error("Lectura erronea en el archivo faovirtes_places.json");
        } catch (NullPointerException nullex){
            mp.error("El archivo favorites_places.json se guardo de forma errónea. " +
                    "\nY no se ha podido acceder a la información que contenia." +
                    "\nSe pide al usuario cerrar el bien el programa la próxima vez.");
        }


    }

    /**
     * Añade un sitio a la lista enlazada de sitios favoritos.
     * @param site el sitio a añadir
     * @see Site
     */
    public void addFavoritos (Site site){
        favoritos.add(site);
    }

    /**
     * Guarda la lista enlazada en formato json dentro de un archivo .json
     * @param archivo el archivo .json de destino
     */
    public void saveFavoritos (String archivo){
        JsonArray ja = new JsonArray();
        for (int i = 0; i < favoritos.size(); i++){
            JsonObject joaux = new JsonObject ();
            joaux.addProperty("name", favoritos.get(i).getName());
            joaux.addProperty("street", favoritos.get(i).getCalle());
            ja.add((JsonElement) joaux);
        }
        try {
            FileWriter fw = new FileWriter (archivo);
            BufferedWriter bw = new BufferedWriter (fw);
            bw.write("{\"favorites\":" + ja.toString() + "}");
            bw.flush();
            bw.close();
            fw.close();
        } catch (IOException e){
            mp.error("Error en la escritura del archivo "+archivo+".");
        }
    }

    /**
     * Devuelve la lista enlazada
     * @return LinkedList<Site> la lista enlazada de sitios favoritos
     */
    public LinkedList<Site> getFavoritos (){return favoritos;}
}
